-- =====================================================================
-- RPI retrospective evaluation: extraction from the TAWOS MySQL dump
-- Run each block in MySQL Workbench against the TAWOS schema, then use
-- "Export recordset to an external file" -> CSV with the file name shown.
-- Put the five CSV files in one folder, zip it, and send it back.
-- No free-text columns are exported (titles/descriptions are not needed).
-- =====================================================================

-- Projects that use sprints (scope of the evaluation)
DROP TEMPORARY TABLE IF EXISTS sprint_projects;
CREATE TEMPORARY TABLE sprint_projects AS
SELECT DISTINCT Project_ID FROM Issue WHERE Sprint_ID IS NOT NULL;

-- 1) issue.csv
SELECT i.ID, i.Project_ID, i.Type, i.Priority, i.Status, i.Resolution,
       i.Story_Point, i.Sprint_ID, i.Creation_Date, i.Resolution_Date
FROM Issue i
JOIN sprint_projects p ON p.Project_ID = i.Project_ID;

-- 2) sprint.csv  (small table, all columns)
SELECT * FROM Sprint;

-- 3) issue_link.csv
SELECT il.*
FROM Issue_Link il
JOIN Issue i ON i.ID = il.Issue_ID
JOIN sprint_projects p ON p.Project_ID = i.Project_ID;

-- 4) change_log.csv  (status target kept only for STATUS changes)
SELECT c.Issue_ID, c.Change_Type, c.Field,
       CASE WHEN c.Change_Type = 'STATUS' THEN c.To_String END AS To_Status,
       c.Creation_Date
FROM Change_Log c
JOIN Issue i ON i.ID = c.Issue_ID
JOIN sprint_projects p ON p.Project_ID = i.Project_ID;

-- 5) issue_component.csv
SELECT ic.*
FROM Issue_Component ic
JOIN Issue i ON i.ID = ic.Issue_ID
JOIN sprint_projects p ON p.Project_ID = i.Project_ID;

-- 6) priority_history.csv  (priority changes, used to reconstruct priority at sprint start)
SELECT c.Issue_ID, c.From_String, c.To_String, c.Creation_Date
FROM Change_Log c
JOIN Issue i ON i.ID = c.Issue_ID
JOIN sprint_projects p ON p.Project_ID = i.Project_ID
WHERE LOWER(c.Field) = 'priority';
