# Extracts the Issue, Sprint, Project and Change_Log tables from the TAWOS dump,
# without the long text columns (titles, descriptions), into small CSV files.
# Reads the .zip directly; no need to unzip.
#
# Usage (either):
#   powershell -ExecutionPolicy Bypass -File extract_tables.ps1
#       -> searches for TAWOS*.zip / TAWOS*.sql in this folder, Downloads, Desktop and Documents
#   powershell -ExecutionPolicy Bypass -File extract_tables.ps1 -Src "D:\data\TAWOS.sql.zip"

param([string]$Src = "")

if (-not $Src) {
    $folders = @($PSScriptRoot, (Get-Location).Path,
                 (Join-Path $env:USERPROFILE 'Downloads'),
                 (Join-Path $env:USERPROFILE 'Desktop'),
                 (Join-Path $env:USERPROFILE 'Documents')) |
               Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
    $found = foreach ($f in $folders) {
        Get-ChildItem -Path $f -Filter 'TAWOS*' -File -ErrorAction SilentlyContinue |
            Where-Object { ($_.Extension -eq '.zip' -or $_.Extension -eq '.sql') -and
                           $_.Name -notlike 'tawos_tables*' -and $_.Name -notlike 'tawos_links*' }
    }
    $found = $found | Sort-Object Length -Descending | Select-Object -First 1
    if (-not $found) {
        Write-Host "TAWOS file not found. Run again and give its full path, for example:" -ForegroundColor Yellow
        Write-Host '  powershell -ExecutionPolicy Bypass -File extract_tables.ps1 -Src "D:\data\TAWOS.sql.zip"'
        exit 1
    }
    $Src = $found.FullName
}
if (-not (Test-Path $Src)) {
    Write-Host "File not found: $Src" -ForegroundColor Yellow
    exit 1
}
Write-Host "Using: $Src"
$out = Join-Path $PSScriptRoot "tawos_tables"

Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

public static class TX
{
    static string Csv(string v)
    {
        if (v == null) return "";
        if (v.IndexOfAny(new char[] { ',', '"', '\n', '\r' }) >= 0)
            return "\"" + v.Replace("\"", "\"\"") + "\"";
        return v;
    }

    static List<List<string>> ParseValues(string s, int i)
    {
        var rows = new List<List<string>>();
        int n = s.Length;
        var sb = new StringBuilder();
        while (i < n)
        {
            while (i < n && s[i] != '(' && s[i] != ';') i++;
            if (i >= n || s[i] == ';') break;
            i++;
            var row = new List<string>();
            bool inq = false, quoted = false;
            sb.Length = 0;
            while (i < n)
            {
                char c = s[i];
                if (inq)
                {
                    if (c == '\\' && i + 1 < n)
                    {
                        char x = s[i + 1];
                        if (x == 'n') sb.Append('\n');
                        else if (x == 't') sb.Append('\t');
                        else if (x == 'r') sb.Append('\r');
                        else if (x == '0' || x == 'Z') { }
                        else sb.Append(x);
                        i += 2; continue;
                    }
                    if (c == '\'')
                    {
                        if (i + 1 < n && s[i + 1] == '\'') { sb.Append('\''); i += 2; continue; }
                        inq = false; i++; continue;
                    }
                    sb.Append(c); i++; continue;
                }
                if (c == '\'') { inq = true; quoted = true; i++; continue; }
                if (c == ',' || c == ')')
                {
                    string v = sb.ToString();
                    if (!quoted) { v = v.Trim(); if (v == "NULL") v = null; }
                    row.Add(v); sb.Length = 0; quoted = false; i++;
                    if (c == ')') { rows.Add(row); break; }
                    continue;
                }
                sb.Append(c); i++;
            }
        }
        return rows;
    }

    // keep: table name -> columns to keep (null = all columns)
    public static string Run(Stream stream, string outDir)
    {
        var keep = new Dictionary<string, string[]>();
        keep["Issue"] = new string[] { "ID", "Issue_Key", "Project_ID", "Type", "Priority", "Status", "Resolution",
                                       "Story_Point", "Sprint_ID", "Creation_Date", "Resolution_Date" };
        keep["Sprint"] = null;
        keep["Project"] = new string[] { "ID", "Name", "Project_Key", "Key" };
        keep["Change_Log"] = new string[] { "ID", "Issue_ID", "Field", "Change_Type", "Creation_Date" };

        Directory.CreateDirectory(outDir);
        var cols = new Dictionary<string, List<string>>();
        var writers = new Dictionary<string, StreamWriter>();
        var idx = new Dictionary<string, int[]>();
        var counts = new Dictionary<string, long>();
        var reader = new StreamReader(stream, Encoding.UTF8, false, 1 << 20);
        string line; string cur = null; long ln = 0;

        while ((line = reader.ReadLine()) != null)
        {
            ln++;
            if (ln % 50000 == 0)
            {
                var sbm = new StringBuilder();
                foreach (var kv in counts) sbm.Append(kv.Key + "=" + kv.Value + " ");
                Console.WriteLine(ln + " lines read. Rows kept: " + sbm.ToString());
            }
            if (cur != null)
            {
                if (line.StartsWith(")")) { cur = null; continue; }
                string t = line.TrimStart();
                if (t.StartsWith("`")) { int k = t.IndexOf('`', 1); cols[cur].Add(t.Substring(1, k - 1)); }
                continue;
            }
            if (line.StartsWith("CREATE TABLE `"))
            {
                int k = line.IndexOf('`', 14);
                string name = line.Substring(14, k - 14);
                if (keep.ContainsKey(name)) { cur = name; cols[name] = new List<string>(); }
                continue;
            }
            if (!line.StartsWith("INSERT INTO `")) continue;
            int e = line.IndexOf('`', 13);
            string tbl = line.Substring(13, e - 13);
            if (!keep.ContainsKey(tbl)) continue;

            int p = line.IndexOf("VALUES", e, StringComparison.Ordinal);
            if (p < 0) continue;
            // optional explicit column list: INSERT INTO `T` (`a`,`b`) VALUES
            string between = line.Substring(e + 1, p - e - 1).Trim();
            if (between.StartsWith("("))
            {
                var list = new List<string>();
                foreach (var part in between.Trim('(', ')').Split(','))
                    list.Add(part.Trim().Trim('`'));
                cols[tbl] = list;
            }
            if (!writers.ContainsKey(tbl))
            {
                List<string> all = cols.ContainsKey(tbl) ? cols[tbl] : new List<string>();
                var want = new List<int>();
                var header = new List<string>();
                for (int j = 0; j < all.Count; j++)
                    if (keep[tbl] == null || Array.IndexOf(keep[tbl], all[j]) >= 0) { want.Add(j); header.Add(all[j]); }
                idx[tbl] = want.ToArray();
                var w = new StreamWriter(Path.Combine(outDir, tbl.ToLower() + ".csv"), false, new UTF8Encoding(false));
                w.WriteLine(string.Join(",", header.ToArray()));
                writers[tbl] = w; counts[tbl] = 0;
            }
            int fieldPos = -1;
            if (tbl == "Change_Log") fieldPos = cols[tbl].IndexOf("Field");
            var wr = writers[tbl]; var ix = idx[tbl];
            foreach (var row in ParseValues(line, p + 6))
            {
                if (fieldPos >= 0)
                {
                    string f = fieldPos < row.Count ? row[fieldPos] : null;
                    if (f == null) continue;
                    string fl = f.ToLowerInvariant();
                    if (fl != "sprint" && fl != "story points") continue;
                }
                var outv = new string[ix.Length];
                for (int j = 0; j < ix.Length; j++) outv[j] = ix[j] < row.Count ? Csv(row[ix[j]]) : "";
                wr.WriteLine(string.Join(",", outv));
                counts[tbl]++;
            }
        }
        foreach (var w in writers.Values) w.Close();
        var res = new StringBuilder();
        foreach (var kv in counts) res.Append(kv.Key + ": " + kv.Value + " rows; ");
        return res.ToString();
    }
}

'@

if ($Src.ToLower().EndsWith('.zip')) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip    = [IO.Compression.ZipFile]::OpenRead($Src)
    $entry  = $zip.Entries | Where-Object { $_.Name -like '*.sql' } | Select-Object -First 1
    $stream = $entry.Open()
} else {
    $zip    = $null
    $stream = [IO.File]::OpenRead($Src)
}

$summary = [TX]::Run($stream, $out)
$stream.Close(); if ($zip) { $zip.Dispose() }
Write-Host $summary

Compress-Archive -Path (Join-Path $out '*') -DestinationPath "$out.zip" -Force
"Done. Upload this file: $out.zip  ({0:N1} MB)" -f ((Get-Item "$out.zip").Length / 1MB)
