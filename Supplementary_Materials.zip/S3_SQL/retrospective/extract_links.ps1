# Extracts only Issue_Link, Issue_Component and Component from the TAWOS dump.
# Reads the .zip directly (no need to unzip 4 GB). Output: tawos_links.sql.zip (a few MB).
# Usage: change the path below, then run:  powershell -ExecutionPolicy Bypass -File extract_links.ps1

$src    = "C:\Users\YOU\Downloads\TAWOS.sql.zip"   # or the unzipped TAWOS.sql
$tables = @('Issue_Link', 'Issue_Component', 'Component')
$outSql = Join-Path (Split-Path $src) "tawos_links.sql"

if ($src.ToLower().EndsWith('.zip')) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip    = [IO.Compression.ZipFile]::OpenRead($src)
    $entry  = $zip.Entries | Where-Object { $_.Name -like '*.sql' } | Select-Object -First 1
    $stream = $entry.Open()
} else {
    $zip    = $null
    $stream = [IO.File]::OpenRead($src)
}
$reader = New-Object IO.StreamReader($stream, [Text.Encoding]::UTF8)
$writer = New-Object IO.StreamWriter($outSql, $false, (New-Object Text.UTF8Encoding $false))

$inCreate = $false; $n = 0; $kept = 0
while ($null -ne ($line = $reader.ReadLine())) {
    $n++
    if ($inCreate) {
        $writer.WriteLine($line)
        if ($line.StartsWith(')')) { $inCreate = $false }
        continue
    }
    foreach ($t in $tables) {
        if ($line.StartsWith("CREATE TABLE ``$t``")) { $writer.WriteLine($line); $inCreate = $true; break }
        if ($line.StartsWith("INSERT INTO ``$t``"))  { $writer.WriteLine($line); $kept++; break }
    }
    if ($n % 100000 -eq 0) { Write-Host "$n lines read, $kept insert lines kept..." }
}
$reader.Close(); $writer.Close(); if ($zip) { $zip.Dispose() }

Compress-Archive -Path $outSql -DestinationPath "$outSql.zip" -Force
"Done. Upload this file: $outSql.zip  ({0:N1} MB)" -f ((Get-Item "$outSql.zip").Length / 1MB)
