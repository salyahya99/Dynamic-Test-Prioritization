SELECT
    i.Jira_ID          AS ExternalID,
    i.Issue_Key        AS SourceKey,
    i.Description      AS Summary,
    i.Type             AS IssueType,
    i.Priority         AS Priority,
    i.Creation_Date    AS CreatedDate,
    i.Resolution_Date  AS ResolvedDate
    
FROM Issue i
WHERE i.Project_ID = '34'
    AND i.Type = 'Bug'
    AND Sprint_ID IN (4049,4050,4052,3921)