WITH sprint_window AS (
    SELECT
        Sprint_ID,
        MIN(Creation_Date) AS Sprint_Start,
        MAX(Creation_Date) AS Sprint_End,
        SUM(CASE WHEN Type IN('Story','Task','Improvement','New Feature') THEN 1 ELSE 0 END) AS Story_Count,
        SUM(CASE WHEN Type='Bug' THEN 1 ELSE 0 END) AS Bug_Count
    FROM Issue
    WHERE Project_ID = '34'
        AND Sprint_ID IS NOT NULL
    GROUP BY Sprint_ID
)
SELECT *
FROM sprint_window
WHERE story_count > 0 AND bug_count > 0
ORDER BY sprint_start;

-- Select 4 sprints '3921,4052,4050,4049' - figure 9 in report