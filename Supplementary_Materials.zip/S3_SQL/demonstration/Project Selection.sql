SELECT 
p.name AS project_name, 
COUNT(i.id) AS total_issues,
p.id As Project_Id

FROM Project p
JOIN Issue i ON i.project_id = p.id
GROUP BY 
p.name, 
p.id;

-- Slect project 'Moodle' , 34 for this study