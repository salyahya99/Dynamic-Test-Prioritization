SELECT
    il.Issue_ID        AS BugExternalID,
    il.Target_Issue_ID AS ReqExternalID,
    il.Name            AS LinkType
FROM Issue_Link il
JOIN Issue b ON il.Issue_ID = b.ID
JOIN Issue r ON il.Target_Issue_ID = r.ID
WHERE b.Project_ID = 34
    AND b.Sprint_ID IN (4049,4050,4052,3921)
    AND b.Type = 'Bug';