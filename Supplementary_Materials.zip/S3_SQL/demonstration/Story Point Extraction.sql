SELECT
    i.Jira_ID       AS ExternalID,
    i.Issue_Key     AS SourceKey,
    i.Description   AS Summary,
    i.Type          AS IssueType,
    i.Priority      AS Priority,
    i.Creation_Date AS CreatedDate,
    i.Sprint_ID AS Sprint_ID,
    i.story_point As Story_Point
FROM Issue i
WHERE i.Project_ID = '34' and i.story_point is not null and i.sprint_ID in (3921,4052,4050,4049) 
    AND i.Type IN('Story','New Feature','Improvement','Task')
    
    -- Story point for Functional Importance factor