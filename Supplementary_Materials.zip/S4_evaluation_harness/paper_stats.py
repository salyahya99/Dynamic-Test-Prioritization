"""Statistics reported in the paper, computed from per_sprint_results.csv.

Paired differences are tested with the Wilcoxon signed-rank test over sprints and summarised with
95% confidence intervals from a cluster bootstrap that resamples whole projects, so that sprints of
the same project are not treated as independent.

Usage: python paper_stats.py RESULTS_DIR [--exclude-project ID]
"""
import argparse, json, os
import numpy as np
import pandas as pd
from scipy import stats

COMPARISONS = [
    ("R20",   "RPI risk factors only", "Random"),
    ("R20",   "RPI risk factors only", "Jira priority only"),
    ("R20",   "RPI (default weights)", "Random"),
    ("R20",   "RPI (default weights)", "Jira priority only"),
    ("APFD",  "RPI risk factors only", "Random"),
    ("APFD",  "RPI risk factors only", "Jira priority only"),
    ("APFD",  "RPI risk factors only", "Defect density only"),
    ("APFD",  "RPI (default weights)", "Random"),
    ("APFD",  "Jira priority only",    "Random"),
    ("APFDc", "RPI (default weights)", "Random"),
    ("APFDc", "RPI (default weights)", "Jira priority only"),
    ("APFD",  "Learned weights (LR)",  "RPI (default weights)"),
]


def a12(x, y):
    x, y = np.asarray(x), np.asarray(y)
    return float(((x[:, None] > y[None, :]).sum() + 0.5 * (x[:, None] == y[None, :]).sum()) / (len(x) * len(y)))


def cluster_ci(df, col, B=4000, seed=1):
    rng = np.random.default_rng(seed)
    groups = [g[col].values for _, g in df.groupby("Project_ID")]
    boot = [np.concatenate([groups[i] for i in rng.integers(0, len(groups), len(groups))]).mean() for _ in range(B)]
    return [float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))]


def compare(per):
    out = []
    for m, a, b in COMPARISONS:
        ca, cb = f"{m}|{a}", f"{m}|{b}"
        if ca not in per or cb not in per:
            continue
        d = per[["Project_ID", ca, cb]].dropna()
        d = d.assign(diff=d[ca] - d[cb])
        ci = cluster_ci(d, "diff")
        out.append(dict(metric=m, a=a, b=b, n_sprints=len(d), n_projects=int(d.Project_ID.nunique()),
                        mean_a=float(d[ca].mean()), mean_b=float(d[cb].mean()), diff=float(d["diff"].mean()),
                        ci95_project_bootstrap=ci, robust=bool(ci[0] > 0 or ci[1] < 0),
                        wilcoxon_p=float(stats.wilcoxon(d[ca], d[cb]).pvalue) if d["diff"].abs().sum() > 0 else 1.0,
                        A12=a12(d[ca].values, d[cb].values)))
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("results"); ap.add_argument("--exclude-project", type=int, default=None)
    a = ap.parse_args()
    per = pd.read_csv(os.path.join(a.results, "per_sprint_results.csv"))
    res = {"all": compare(per)}
    if a.exclude_project is not None:
        res[f"without_project_{a.exclude_project}"] = compare(per[per.Project_ID != a.exclude_project])
    json.dump(res, open(os.path.join(a.results, "paper_stats.json"), "w"), indent=1)
    for k, rows in res.items():
        print("==", k)
        for r in rows:
            print(f"  {r['metric']:5s} {r['a'][:22]:22s} vs {r['b'][:20]:20s} {r['mean_a']:.3f} vs {r['mean_b']:.3f} "
                  f"diff {r['diff']:+.3f} CI [{r['ci95_project_bootstrap'][0]:+.3f},{r['ci95_project_bootstrap'][1]:+.3f}]"
                  f"{' robust' if r['robust'] else ''}  p={r['wilcoxon_p']:.3f}  A12={r['A12']:.2f}")
