"""Build the pipeline inputs from
  (a) the public 8-project TAWOS export (github.com/hani-ziad/AdvAI_Assign1_Maryam_Hani,
      data/raw/tawos: tawos_issue.csv, tawos_sprint.csv, tawos_change_log.csv), and
  (b) the Issue_Link / Issue_Component tables parsed from the full dump (parse_dump.py).
Usage: python prep_subset.py SUBSET_DIR PARSED_DIR OUT_DIR"""
import os, sys, shutil
import pandas as pd

sub, parsed, out = sys.argv[1:4]
os.makedirs(out, exist_ok=True)
iss = pd.read_csv(os.path.join(sub, "tawos_issue.csv"), low_memory=False)
ids = set(iss.ID)
iss.to_csv(os.path.join(out, "issue.csv"), index=False)
shutil.copy(os.path.join(sub, "tawos_sprint.csv"), os.path.join(out, "sprint.csv"))
shutil.copy(os.path.join(sub, "tawos_change_log.csv"), os.path.join(out, "change_log.csv"))

lnk = pd.read_csv(os.path.join(parsed, "issue_link.csv"))
lnk = lnk[lnk.Issue_ID.isin(ids) | lnk.Target_Issue_ID.isin(ids)]
lnk.to_csv(os.path.join(out, "issue_link.csv"), index=False)
p = os.path.join(parsed, "issue_component.csv")
if os.path.exists(p):
    ic = pd.read_csv(p); ic[ic.Issue_ID.isin(ids)].to_csv(os.path.join(out, "issue_component.csv"), index=False)
print(f"issues={len(iss)} links={len(lnk)}")
