"""Convert a mysqldump extract (CREATE TABLE + INSERT INTO lines) into one CSV per table.
Usage: python parse_dump.py tawos_links.sql OUTDIR"""
import csv, os, re, sys


def parse_values(s, i):
    """Yield tuples from 'VALUES (...),(...);' starting at index i."""
    n = len(s)
    while i < n:
        while i < n and s[i] not in "(;":
            i += 1
        if i >= n or s[i] == ";":
            return
        i += 1; row = []; buf = []; inq = False
        while i < n:
            c = s[i]
            if inq:
                if c == "\\" and i + 1 < n:
                    nxt = s[i + 1]
                    buf.append({"n": "\n", "t": "\t", "r": "\r", "0": "\0"}.get(nxt, nxt)); i += 2; continue
                if c == "'":
                    if i + 1 < n and s[i + 1] == "'":
                        buf.append("'"); i += 2; continue
                    inq = False; i += 1; continue
                buf.append(c); i += 1; continue
            if c == "'":
                inq = True; i += 1; continue
            if c in ",)":
                v = "".join(buf).strip()
                row.append(None if v == "NULL" else v); buf = []
                i += 1
                if c == ")":
                    yield row; break
                continue
            buf.append(c); i += 1


def main(path, out):
    os.makedirs(out, exist_ok=True)
    cols, writers, files, counts = {}, {}, {}, {}
    cur = None
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = re.match(r"CREATE TABLE `([^`]+)`", line)
            if m:
                cur = m.group(1); cols[cur] = []; continue
            if cur and line.startswith(")"):
                cur = None; continue
            if cur:
                mc = re.match(r"\s+`([^`]+)`", line)
                if mc:
                    cols[cur].append(mc.group(1))
                continue
            mi = re.match(r"INSERT INTO `([^`]+)`(?:\s*\(([^)]*)\))?\s+VALUES\s*", line)
            if mi:
                t = mi.group(1)
                header = [c.strip(" `") for c in mi.group(2).split(",")] if mi.group(2) else cols.get(t)
                if t not in writers:
                    files[t] = open(os.path.join(out, f"{t.lower()}.csv"), "w", newline="", encoding="utf-8")
                    writers[t] = csv.writer(files[t]); counts[t] = 0
                    if header:
                        writers[t].writerow(header)
                for row in parse_values(line, mi.end()):
                    writers[t].writerow(["" if v is None else v for v in row]); counts[t] += 1
    for fh in files.values():
        fh.close()
    print(counts)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
