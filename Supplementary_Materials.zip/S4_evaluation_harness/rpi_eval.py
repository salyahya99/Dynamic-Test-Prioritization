"""
Retrospective, requirement-level evaluation of the Risk-Based Priority Index (RPI)
on real TAWOS data.

Design (rolling origin, no look-ahead):
  * Unit of ranking: requirement items (Story, Task, Improvement, New Feature)
    assigned to sprint k.
  * Cut-off t_k = sprint start. Every factor uses only records dated before t_k.
  * Outcome: the item is "faulty" if at least one Bug linked to it is created in
    [t_k, sprint end + horizon].
  * Metric: APFD (ties scored with mid-ranks = expected APFD under random
    tie-breaking), plus ROC-AUC and Precision@20%.

Factor operationalisation on real data (requirement level). Fragility and
recurrence are test-execution concepts with no execution log in TAWOS, so they
are replaced by requirement/component-level proxies and reported as such.

Usage:
    python rpi_eval.py --data DIR --out OUT [--horizon 30] [--min-items 10]
"""
import argparse, json, os, warnings
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression

warnings.filterwarnings("ignore")
RNG = np.random.default_rng(42)

REQ_TYPES = {"story", "task", "improvement", "new feature"}
BUG_TYPES = {"bug"}
FACTORS = ["fragility", "defect_density", "recurrence", "volatility",
           "importance", "feasibility"]
DEFAULT_W = dict(fragility=0.26, defect_density=0.17, recurrence=0.20,
                 volatility=0.15, importance=0.13, feasibility=0.09)
# Weight ranges from the original study (Final Report, Table 1)
W_RANGES = dict(fragility=(0.22, 0.28), defect_density=(0.15, 0.18),
                recurrence=(0.18, 0.22), volatility=(0.13, 0.17),
                importance=(0.10, 0.15), feasibility=(0.05, 0.10))
PRIORITY_RANK = {  # higher = more important; covers the schemes used in TAWOS
    "blocker": 5, "critical": 4, "highest": 5, "high": 4, "major": 3,
    "medium": 3, "minor": 2, "low": 2, "trivial": 1, "lowest": 1,
    "p1": 5, "p2": 4, "p3": 3, "p4": 2, "p5": 1}


# ----------------------------------------------------------------- loading
def _col(df, *cands):
    low = {c.lower(): c for c in df.columns}
    for c in cands:
        if c.lower() in low:
            return low[c.lower()]
    raise KeyError(f"none of {cands} in {list(df.columns)}")


def load(d):
    rd = lambda f: pd.read_csv(os.path.join(d, f), low_memory=False)
    iss = rd("issue.csv")
    iss.columns = [c.strip() for c in iss.columns]
    if not any(c.lower() == "project_id" for c in iss.columns):
        names = iss[_col(iss, "Project_Name")].astype(str).str.strip()
        iss["Project_ID"] = names.astype("category").cat.codes + 1
    iss = iss.rename(columns={_col(iss, "ID"): "ID", _col(iss, "Project_ID"): "Project_ID",
                              _col(iss, "Type"): "Type", _col(iss, "Priority"): "Priority",
                              _col(iss, "Story_Point"): "Story_Point",
                              _col(iss, "Sprint_ID"): "Sprint_ID",
                              _col(iss, "Creation_Date"): "Creation_Date"})
    iss["Creation_Date"] = pd.to_datetime(iss["Creation_Date"], errors="coerce")
    iss["Resolution_Date"] = pd.to_datetime(iss[_col(iss, "Resolution_Date")], errors="coerce")
    iss["type_l"] = iss["Type"].astype(str).str.lower().str.strip()

    spr = rd("sprint.csv")
    sid = _col(spr, "ID")
    start = pd.to_datetime(spr[_col(spr, "Start_Date")], errors="coerce")
    try:
        start = start.fillna(pd.to_datetime(spr[_col(spr, "Activated_Date")], errors="coerce"))
    except KeyError:
        pass
    end = pd.to_datetime(spr[_col(spr, "End_Date")], errors="coerce")
    try:
        end = pd.to_datetime(spr[_col(spr, "Completion_Date", "Complete_Date")], errors="coerce").fillna(end)
    except KeyError:
        pass
    spr = pd.DataFrame({"Sprint_ID": spr[sid], "start": start, "end": end}).dropna()
    spr = spr[spr["end"] > spr["start"]]

    lnk = rd("issue_link.csv")
    lnk = pd.DataFrame({"a": lnk[_col(lnk, "Issue_ID")], "b": lnk[_col(lnk, "Target_Issue_ID")]})
    lnk = pd.concat([lnk, lnk.rename(columns={"a": "b", "b": "a"})]).drop_duplicates()

    chg = rd("change_log.csv")
    chg = pd.DataFrame({"Issue_ID": chg[_col(chg, "Issue_ID")],
                        "ctype": chg[_col(chg, "Change_Type")].astype(str).str.upper(),
                        "to_status": (chg[_col(chg, "To_Status", "To_String")].astype(str).str.lower()
                                      if any(c.lower() in ("to_status", "to_string") for c in chg.columns) else ""),
                        "date": pd.to_datetime(chg[_col(chg, "Creation_Date")], errors="coerce"),
                        "field": (chg[_col(chg, "Field")].astype(str).str.lower().str.strip()
                                  if any(c.lower() == "field" for c in chg.columns) else "")})

    cmp_path = os.path.join(d, "issue_component.csv")
    if os.path.exists(cmp_path):
        cmp = rd("issue_component.csv")
        cmp = pd.DataFrame({"Issue_ID": cmp[_col(cmp, "Issue_ID")],
                            "Component_ID": cmp[_col(cmp, "Component_ID")]})
    else:
        cmp = pd.DataFrame(columns=["Issue_ID", "Component_ID"])
    ph_path = os.path.join(d, "priority_history.csv")
    if os.path.exists(ph_path):
        ph = rd("priority_history.csv")
        ph = pd.DataFrame({"Issue_ID": ph[_col(ph, "Issue_ID")],
                           "from": ph[_col(ph, "From_String")],
                           "date": pd.to_datetime(ph[_col(ph, "Creation_Date")], errors="coerce")}).dropna(subset=["date"])
        ph = ph.sort_values("date")
    else:
        ph = None
    return iss, spr, lnk, chg, cmp, ph


# ----------------------------------------------------------------- helpers
def minmax(x):
    x = np.asarray(x, float)
    lo, hi = np.nanmin(x), np.nanmax(x)
    return np.zeros_like(x) if hi - lo < 1e-12 else (x - lo) / (hi - lo)


def apfd(score, y):
    """Expected APFD under random tie-breaking (mid-ranks)."""
    y = np.asarray(y, bool); n, m = len(y), y.sum()
    if m == 0 or m == n:
        return np.nan
    ranks = stats.rankdata(-np.asarray(score, float), method="average")
    return 1 - ranks[y].sum() / (n * m) + 1 / (2 * n)


def apfdc(score, y, cost, reps=30):
    """Cost-cognizant APFD (Elbaum et al. 2001), uniform fault severity,
    averaged over random tie-breaks."""
    y = np.asarray(y, bool); c = np.asarray(cost, float); m = y.sum()
    if m == 0 or m == len(y):
        return np.nan
    vals = []
    for _ in range(reps):
        o = np.lexsort((RNG.random(len(y)), -np.asarray(score, float)))
        yc, cc = y[o], c[o]
        tail = np.cumsum(cc[::-1])[::-1]          # sum of costs from position j to n
        vals.append(((tail - 0.5 * cc)[yc]).sum() / (cc.sum() * m))
    return float(np.mean(vals))


def auc(score, y):
    y = np.asarray(y, bool)
    if y.all() or (~y).all():
        return np.nan
    r = stats.rankdata(score)
    return (r[y].sum() - y.sum() * (y.sum() + 1) / 2) / (y.sum() * (~y).sum())


def p_at(score, y, frac=0.2):
    k = max(1, int(round(frac * len(y))))
    order = np.argsort(-np.asarray(score, float) + RNG.random(len(y)) * 1e-9)
    return np.asarray(y)[order[:k]].mean()


def recall_at(score, y, frac=0.2):
    """Expected share of faulty items within the first `frac` of the ranking (random tie-breaking)."""
    score = np.asarray(score, float); y = np.asarray(y, bool); n, m = len(y), y.sum()
    if m == 0:
        return np.nan
    k = frac * n; o = np.argsort(-score, kind="stable"); sc = score[o]; yy = y[o]
    got = taken = 0.0; i = 0
    while i < n and taken < k:
        j = i
        while j + 1 < n and sc[j + 1] == sc[i]:
            j += 1
        size = j - i + 1; room = min(size, k - taken)
        got += yy[i:j + 1].sum() * room / size; taken += room; i = j + 1
    return got / m


def a12(x, y):
    """Vargha-Delaney A12 (probability x > y)."""
    x, y = np.asarray(x), np.asarray(y)
    gt = (x[:, None] > y[None, :]).sum(); eq = (x[:, None] == y[None, :]).sum()
    return (gt + 0.5 * eq) / (len(x) * len(y))


# --------------------------------------------------------- factor building
def build_snapshots(iss, spr, lnk, chg, cmp, ph, horizon_days, min_items):
    ptype = iss.set_index("ID")["type_l"]
    pdate = iss.set_index("ID")["Creation_Date"]
    pres = iss.set_index("ID")["Resolution_Date"]
    bug_ids = set(iss.loc[iss.type_l.isin(BUG_TYPES), "ID"])
    req = iss[iss.type_l.isin(REQ_TYPES) & iss.Sprint_ID.notna()].merge(spr, on="Sprint_ID")
    proj_of_sprint = req.groupby("Sprint_ID")["Project_ID"].agg(lambda s: s.mode().iat[0])
    req = req[req.Project_ID == req.Sprint_ID.map(proj_of_sprint)]

    # link tables
    bl = lnk[lnk.b.isin(bug_ids)].copy(); bl["bug_date"] = bl.b.map(pdate)
    bl["bug_res"] = bl.b.map(pres)
    dep = lnk[~lnk.b.isin(bug_ids)]          # non-bug links only (no outcome leakage)
    dep_cnt = dep.groupby("a").size()
    comp_of = cmp.groupby("Issue_ID")["Component_ID"].apply(list)
    # volatility: sprint reassignments and story-point revisions only (Section 6.1.1)
    edits = chg[chg.field.isin({"sprint", "story points"})] if chg.field.ne("").any() \
        else chg[chg.ctype != "STATUS"]
    cmp_issue = cmp.merge(iss[["ID", "type_l", "Creation_Date"]], left_on="Issue_ID", right_on="ID")

    # priority history: the priority an item had at time t is the "from" value of its
    # first priority change after t, or its final value if it was not changed after t
    prio_hist = {} if ph is None else {i: (h.date.values, h["from"].values) for i, h in ph.groupby("Issue_ID")}
    def prio_at(iid, final, t):
        if iid in prio_hist:
            dates, frm = prio_hist[iid]
            k = np.searchsorted(dates, np.datetime64(t), side="right")
            if k < len(dates):
                return frm[k]
        return final

    rows = []
    for sid, g in req.groupby("Sprint_ID"):
        if len(g) < min_items:
            continue
        t0, t1 = g.start.iat[0], g.end.iat[0] + pd.Timedelta(days=horizon_days)
        ids = g.ID.values
        my_bl = bl[bl.a.isin(ids)]
        # outcome
        fut = my_bl[(my_bl.bug_date >= t0) & (my_bl.bug_date <= t1)].groupby("a").size()
        y = np.array([fut.get(i, 0) > 0 for i in ids])
        if y.sum() == 0:
            continue
        # fragility proxy: bugs linked to the item before t0
        past = my_bl[my_bl.bug_date < t0].groupby("a").size()
        frag = np.array([past.get(i, 0) for i in ids], float)
        # component-level defect density and reopen (recurrence) rate before t0
        ci = cmp_issue[cmp_issue.Creation_Date < t0]
        cbug = ci[ci.type_l.isin(BUG_TYPES)].groupby("Component_ID").size()
        creq = ci[ci.type_l.isin(REQ_TYPES)].groupby("Component_ID").size()
        proj_bug = ((iss.Project_ID == g.Project_ID.iat[0]) & iss.type_l.isin(BUG_TYPES)
                    & (iss.Creation_Date < t0)).sum()
        proj_req = ((iss.Project_ID == g.Project_ID.iat[0]) & iss.type_l.isin(REQ_TYPES)
                    & (iss.Creation_Date < t0)).sum()
        dd = []
        for i in ids:
            cs = comp_of.get(i, [])
            dd.append(max(cbug.get(c, 0) / max(creq.get(c, 0), 1) for c in cs) if cs
                      else proj_bug / max(proj_req, 1))
        # recurrence (Fail->Pass->Fail analogue): linked bugs created before t0 after an
        # earlier linked bug of the same item had already been resolved
        hist = my_bl[my_bl.bug_date < t0]
        rel = {}
        for i, h in hist.groupby("a"):
            res = h.bug_res[h.bug_res < t0].values
            rel[i] = sum(any(r < c for r in res) for c in h.bug_date.values)
        rc = [rel.get(i, 0) for i in ids]
        # volatility: non-status edits on the item before t0
        ev = edits[(edits.Issue_ID.isin(ids)) & (edits.date < t0)].groupby("Issue_ID").size()
        vol = np.array([ev.get(i, 0) for i in ids], float)
        # importance
        prio_t0 = pd.Series([prio_at(i, f, t0) for i, f in zip(g.ID.values, g.Priority.values)], index=g.index)
        pr = prio_t0.map(lambda v: PRIORITY_RANK.get(str(v).lower().split(" - ")[0].strip()) if pd.notna(v) else None).astype(float)  # "Major - P3" -> "major"
        imp = pr.fillna(pr.median() if pr.notna().any() else 3).values
        # feasibility: effort (missing SP -> sprint median, not 0) and dependencies
        sp = pd.to_numeric(g.Story_Point, errors="coerce")
        sp = sp.fillna(sp.median() if sp.notna().any() else 0).values
        effort = 1 - (sp / sp.max() if sp.max() > 0 else np.zeros_like(sp))
        deps = np.array([dep_cnt.get(i, 0) for i in ids], float)
        depf = 1 - (deps / deps.max() if deps.max() > 0 else np.zeros_like(deps))
        feas = (effort + depf) / 2
        raw = dict(fragility=frag, defect_density=np.array(dd), recurrence=np.array(rc),
                   volatility=vol, importance=imp, feasibility=feas)
        snap = pd.DataFrame({"Sprint_ID": sid, "Project_ID": g.Project_ID.iat[0],
                             "start": t0, "Issue_ID": ids, "y": y,
                             "priority_raw": imp, "cost": np.maximum(sp, 0.5)})
        for f in FACTORS:
            snap[f] = minmax(raw[f])
        rows.append(snap)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


# ---------------------------------------------------------------- scoring
def rpi(df, w):
    s = sum(w[f] for f in FACTORS)
    return sum(df[f].values * w[f] / s for f in FACTORS)


def learned_scores(snaps):
    """Logistic regression trained only on earlier sprints of the same project."""
    out = pd.Series(np.nan, index=snaps.index)
    for pid, gp in snaps.groupby("Project_ID"):
        starts = gp.drop_duplicates("Sprint_ID").sort_values("start")
        for _, r in starts.iterrows():
            tr = gp[gp.start < r.start]
            if tr.y.nunique() < 2 or len(tr) < 30:
                continue
            m = LogisticRegression(max_iter=1000, class_weight="balanced")
            m.fit(tr[FACTORS], tr.y)
            te = gp.Sprint_ID == r.Sprint_ID
            out[te[te].index] = m.predict_proba(gp.loc[te, FACTORS])[:, 1]
    return out


def evaluate(snaps, out):
    os.makedirs(out, exist_ok=True)
    snaps = snaps.copy()
    eq = {f: 1 / 6 for f in FACTORS}
    strategies = {
        "RPI (default weights)": lambda d: rpi(d, DEFAULT_W),
        "RPI (equal weights)": lambda d: rpi(d, eq),
        "RPI risk factors only": lambda d: rpi(d, {**DEFAULT_W, "feasibility": 0}),
        "Jira priority only": lambda d: d.priority_raw.values,
        "Defect density only": lambda d: d.defect_density.values,
        "Random": None,
    }
    snaps["learned"] = learned_scores(snaps)

    per = []
    for (pid, sid), d in snaps.groupby(["Project_ID", "Sprint_ID"]):
        row = dict(Project_ID=pid, Sprint_ID=sid, n=len(d), faulty=int(d.y.sum()))
        for name, fn in strategies.items():
            if fn is None:
                row[f"APFD|{name}"] = np.mean([apfd(RNG.random(len(d)), d.y) for _ in range(200)])
                row[f"AUC|{name}"] = 0.5
                row[f"P@20|{name}"] = d.y.mean()
                row[f"R20|{name}"] = 0.2
                row[f"APFDc|{name}"] = np.mean([apfdc(RNG.random(len(d)), d.y, d.cost, 1) for _ in range(100)])
            else:
                s = fn(d)
                row[f"APFD|{name}"] = apfd(s, d.y); row[f"AUC|{name}"] = auc(s, d.y)
                row[f"P@20|{name}"] = p_at(s, d.y)
                row[f"R20|{name}"] = recall_at(s, d.y)
                row[f"APFDc|{name}"] = apfdc(s, d.y, d.cost)
        if d.learned.notna().all():
            row["APFD|Learned weights (LR)"] = apfd(d.learned, d.y)
            row["AUC|Learned weights (LR)"] = auc(d.learned, d.y)
            row["P@20|Learned weights (LR)"] = p_at(d.learned.values, d.y)
            row["R20|Learned weights (LR)"] = recall_at(d.learned.values, d.y)
            row["APFDc|Learned weights (LR)"] = apfdc(d.learned.values, d.y, d.cost)
        per.append(row)
    per = pd.DataFrame(per)
    per.to_csv(os.path.join(out, "per_sprint_results.csv"), index=False)

    # summary + paired tests vs RPI default
    names = [c.split("|", 1)[1] for c in per.columns if c.startswith("APFD|")]
    ref = per["APFD|RPI (default weights)"]
    summ = []
    for nm in names:
        col = per[f"APFD|{nm}"]; mask = col.notna() & ref.notna()
        r = dict(strategy=nm, sprints=int(mask.sum()),
                 APFD_mean=col.mean(), APFD_median=col.median(),
                 AUC_mean=per.get(f"AUC|{nm}", pd.Series(dtype=float)).mean(),
                 P20_mean=per.get(f"P@20|{nm}", pd.Series(dtype=float)).mean(),
                 APFDc_mean=per.get(f"APFDc|{nm}", pd.Series(dtype=float)).mean(),
                 R20_mean=per.get(f"R20|{nm}", pd.Series(dtype=float)).mean())
        if nm != "RPI (default weights)" and mask.sum() >= 5:
            diff = ref[mask] - col[mask]
            r["RPI_minus_this"] = diff.mean()
            r["wilcoxon_p"] = stats.wilcoxon(ref[mask], col[mask]).pvalue if diff.abs().sum() > 0 else 1.0
            r["A12_RPI_vs_this"] = a12(ref[mask].values, col[mask].values)
            bs = [RNG.choice(diff.values, len(diff)).mean() for _ in range(2000)]
            r["diff_CI95"] = f"[{np.percentile(bs, 2.5):.3f}, {np.percentile(bs, 97.5):.3f}]"
            rc_, cc_ = per["APFDc|RPI (default weights)"], per.get(f"APFDc|{nm}")
            if cc_ is not None:
                mk = rc_.notna() & cc_.notna()
                r["APFDc_RPI_minus_this"] = (rc_[mk] - cc_[mk]).mean()
                r["APFDc_wilcoxon_p"] = stats.wilcoxon(rc_[mk], cc_[mk]).pvalue
        summ.append(r)
    summ = pd.DataFrame(summ).sort_values("APFD_mean", ascending=False)
    summ.to_csv(os.path.join(out, "summary_strategies.csv"), index=False)

    # per-project table
    proj = per.groupby("Project_ID").agg(
        sprints=("Sprint_ID", "count"), items=("n", "sum"), faulty=("faulty", "sum"),
        **{f"APFD {nm}": (f"APFD|{nm}", "mean") for nm in
           ["RPI (default weights)", "Jira priority only", "Defect density only", "Random"]})
    proj.to_csv(os.path.join(out, "per_project.csv"))

    # ---- weight sensitivity (Monte Carlo inside Table 1 ranges + ±20% OAT)
    groups = list(snaps.groupby("Sprint_ID"))
    mc = []
    for _ in range(500):
        w = {f: RNG.uniform(*W_RANGES[f]) for f in FACTORS}
        ap, tau = [], []
        for _, d in groups:
            s = rpi(d, w); ap.append(apfd(s, d.y))
            tau.append(stats.kendalltau(s, rpi(d, DEFAULT_W)).correlation)
        mc.append(dict(**{f"w_{f}": w[f] / sum(w.values()) for f in FACTORS},
                       APFD_mean=np.nanmean(ap), kendall_tau_median=np.nanmedian(tau)))
    mc = pd.DataFrame(mc); mc.to_csv(os.path.join(out, "sensitivity_montecarlo.csv"), index=False)

    oat = []
    for f in FACTORS:
        for k in (0.8, 1.2):
            w = dict(DEFAULT_W); w[f] *= k
            ap = [apfd(rpi(d, w), d.y) for _, d in groups]
            tau = [stats.kendalltau(rpi(d, w), rpi(d, DEFAULT_W)).correlation for _, d in groups]
            oat.append(dict(factor=f, change=f"{round((k-1)*100):+d}%",
                            APFD_mean=np.nanmean(ap), kendall_tau_median=np.nanmedian(tau)))
    pd.DataFrame(oat).to_csv(os.path.join(out, "sensitivity_oat.csv"), index=False)

    # ---- ablation (leave one factor out)
    base = np.nanmean([apfd(rpi(d, DEFAULT_W), d.y) for _, d in groups])
    abl = []
    for f in FACTORS:
        w = dict(DEFAULT_W); w[f] = 0
        v = np.nanmean([apfd(rpi(d, w), d.y) for _, d in groups])
        abl.append(dict(removed=f, APFD_mean=v, delta_vs_full=v - base))
    pd.DataFrame(abl).to_csv(os.path.join(out, "ablation.csv"), index=False)

    # ---- univariate signal of each factor
    uni = [dict(factor=f, APFD_mean=np.nanmean([apfd(d[f].values, d.y) for _, d in groups]))
           for f in FACTORS]
    pd.DataFrame(uni).to_csv(os.path.join(out, "single_factor.csv"), index=False)

    X = (snaps[FACTORS] - snaps[FACTORS].mean()) / snaps[FACTORS].std().replace(0, 1)
    lr = LogisticRegression(max_iter=2000, class_weight="balanced").fit(X, snaps.y)
    pd.DataFrame({"factor": FACTORS, "std_coef": lr.coef_[0]}).to_csv(
        os.path.join(out, "lr_coefficients.csv"), index=False)

    plots(per, mc, out)
    meta = dict(projects=int(per.Project_ID.nunique()), sprints=len(per),
                items=int(per.n.sum()), faulty_items=int(per.faulty.sum()),
                base_APFD=base)
    json.dump(meta, open(os.path.join(out, "meta.json"), "w"), indent=2, default=str)
    return summ, meta


def plots(per, mc, out):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    cols = [c for c in per.columns if c.startswith("APFD|")]
    data = [per[c].dropna().values for c in cols]
    lab = [c.split("|", 1)[1] for c in cols]
    fig, ax = plt.subplots(figsize=(8, 4.2))
    ax.boxplot(data, vert=False, labels=lab, showmeans=True)
    ax.axvline(0.5, ls="--", lw=0.8, c="grey")
    ax.set_xlabel("APFD per sprint"); fig.tight_layout()
    fig.savefig(os.path.join(out, "fig_apfd_boxplot.png"), dpi=200); plt.close(fig)
    fig, ax = plt.subplots(figsize=(5, 3.5))
    ax.hist(mc.APFD_mean, bins=30)
    ax.set_xlabel("Mean APFD (weights sampled within Table 1 ranges)")
    ax.set_ylabel("Configurations"); fig.tight_layout()
    fig.savefig(os.path.join(out, "fig_weight_sensitivity.png"), dpi=200); plt.close(fig)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--horizon", type=int, default=30)
    ap.add_argument("--min-items", type=int, default=10)
    a = ap.parse_args()
    snaps = build_snapshots(*load(a.data), a.horizon, a.min_items)
    if snaps.empty:
        raise SystemExit("No eligible sprints found.")
    summ, meta = evaluate(snaps, a.out)
    snaps.to_csv(os.path.join(a.out, "snapshots.csv"), index=False)
    pd.set_option("display.width", 200)
    print(json.dumps(meta, indent=2, default=str)); print(summ.round(3).to_string(index=False))
