# Supplementary Materials

A Transparent Risk-Based Dashboard for Prioritizing Manual Functional and Acceptance Test Cases in Agile Development

| File | Contents |
|---|---|
| S2_DAX_expressions.txt | DAX expressions for the six factors and the RPI (Section 5.3, Table 2) |
| S3_SQL/demonstration | SQL used to select the project and sprints and to extract requirements, defects, links and story points from TAWOS for the demonstration (Sections 3.3, 5.4) |
| S3_SQL/retrospective | SQL that exports the TAWOS tables used in the retrospective evaluation, and PowerShell scripts that extract the same tables directly from the compressed TAWOS dump (Section 6.1) |
| S4_evaluation_harness | Python code of the retrospective evaluation and of the statistics reported in the paper (Section 6.1) |
| S5_results | Results of the retrospective evaluation for the 30-, 0- and 90-day outcome horizons |

TAWOS is not included; it is publicly available at https://doi.org/10.5522/04/21308124.

## Reproducing the retrospective evaluation (S4)

Requirements: Python 3.9+, `pip install pandas numpy scipy scikit-learn matplotlib`.

1. Obtain the input tables from TAWOS in one of two ways, and put them in one folder (for example `data/`):
   * **With MySQL:** run the six queries in `S3_SQL/retrospective/01_extract_tawos.sql` and save the results as
     `issue.csv`, `sprint.csv`, `issue_link.csv`, `change_log.csv`, `issue_component.csv` and `priority_history.csv`.
   * **Without MySQL (Windows PowerShell):** run `extract_tables.ps1`, `extract_links.ps1` and `extract_priority.ps1`
     on the compressed TAWOS dump; convert the links extract with `python parse_dump.py tawos_links.sql data`,
     and rename the priority extract to `priority_history.csv`.
2. Run the evaluation and the statistics reported in the paper:
   ```
   python rpi_eval.py --data data --out results_30 --horizon 30
   python rpi_eval.py --data data --out results_0  --horizon 0
   python rpi_eval.py --data data --out results_90 --horizon 90
   python paper_stats.py results_30 --exclude-project 28
   ```
   Project 28 is LSST Data Management, reported separately because it contributes about half of the sprints.

`priority_history.csv` is used to reconstruct each requirement's priority as it stood at sprint start, for both the
functional importance factor and the Jira-priority baseline.

## Results (S5)

| File | Contents |
|---|---|
| summary_strategies.csv | Mean APFD, APFDc, ROC-AUC, Precision@20% and share of defect-linked items found in the first 20% (R20) per ordering |
| paper_stats.json | Paired comparisons reported in the paper: differences, 95% intervals from a bootstrap that resamples projects, and Wilcoxon p-values, with and without LSST |
| per_project.csv | Results per project |
| per_sprint_results.csv | Every sprint and every ordering |
| sensitivity_montecarlo.csv | 500 weight vectors sampled within the expert-defined ranges |
| sensitivity_oat.csv | Each weight changed by -20% and +20% |
| ablation.csv | Leave-one-factor-out |
| single_factor.csv | Each factor used alone |
| lr_coefficients.csv | Standardised coefficients of the logistic-regression reference model |
| meta.json | Number of projects, sprints, items and defect-linked items |
| per_item_factors.csv (30-day folder) | Normalised factor values and outcome of every requirement in every sprint; Figure 4 is drawn from sprint 2932 in this file |
