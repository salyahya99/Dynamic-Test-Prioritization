# Supplementary Materials

A Transparent Risk-Based Dashboard for Prioritizing Manual Functional and Acceptance Test Cases in Agile Development

| File | Contents |
|---|---|
| S2_DAX_expressions.txt | DAX expressions for the six factors and the RPI (Section 5.3, Table 2) |
| S3_SQL/demonstration | SQL used to select the project and sprints and to extract requirements, defects, links and story points from TAWOS for the demonstration (Sections 3.3, 5.4) |
| S3_SQL/retrospective | SQL that exports the TAWOS tables used in the retrospective evaluation, and a PowerShell script that extracts the link and component tables directly from the TAWOS dump (Section 6.1) |
| S4_evaluation_harness | Python code of the retrospective evaluation (Section 6.1) |
| S5_results | Results of the retrospective evaluation for the 30-, 0- and 90-day outcome horizons |

TAWOS is not included; it is publicly available at https://doi.org/10.5522/04/21308124.

## Reproducing the retrospective evaluation (S4)

Requirements: Python 3.9+, `pip install pandas numpy scipy scikit-learn matplotlib`.

1. Run the five queries in `S3_SQL/retrospective/01_extract_tawos.sql` against the TAWOS database and save the results as
   `issue.csv`, `sprint.csv`, `issue_link.csv`, `change_log.csv` and `issue_component.csv` in one folder (for example `data/`).
2. Run:
   ```
   python rpi_eval.py --data data --out results_30 --horizon 30
   python rpi_eval.py --data data --out results_0  --horizon 0
   python rpi_eval.py --data data --out results_90 --horizon 90
   ```

If MySQL is not available, `extract_links.ps1` streams the compressed TAWOS dump and keeps only the link and component tables;
`parse_dump.py` converts that extract to CSV, and `prep_subset.py` combines it with exported issue, sprint and change-log tables.

## Results (S5)

| File | Contents |
|---|---|
| summary_strategies.csv | Mean APFD, APFDc, ROC-AUC and Precision@20% per ordering; paired Wilcoxon tests, A12 and bootstrap 95% CIs against the default RPI |
| per_project.csv | Results per project |
| per_sprint_results.csv | Every sprint and every ordering |
| sensitivity_montecarlo.csv | 500 weight vectors sampled within the expert-defined ranges |
| sensitivity_oat.csv | Each weight changed by -20% and +20% |
| ablation.csv | Leave-one-factor-out |
| single_factor.csv | Each factor used alone |
| lr_coefficients.csv | Standardised coefficients of the logistic-regression reference model |
| meta.json | Number of projects, sprints, items and defect-linked items |
| per_item_factors.csv (30-day folder) | Normalised factor values and outcome of every requirement in every sprint; Figure 4 is drawn from sprint 2932 in this file |
